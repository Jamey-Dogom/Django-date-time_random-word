from django.apps import AppConfig


class AppTimeConfig(AppConfig):
    name = 'app_time'
